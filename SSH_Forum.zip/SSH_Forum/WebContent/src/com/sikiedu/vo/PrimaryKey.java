package com.sikiedu.vo;

import java.io.Serializable;

import com.sikiedu.domain.Answer;
import com.sikiedu.domain.User;

public class PrimaryKey implements Serializable {

	private User user;
	private Answer answer;
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Answer getAnswer() {
		return answer;
	}
	public void setAnswer(Answer answer) {
		this.answer = answer;
	}
	
	
	
}
